package ru.samsung.gamestudio;

public enum GameState {
    PLAYING,
    PAUSED,
    ENDED
}

